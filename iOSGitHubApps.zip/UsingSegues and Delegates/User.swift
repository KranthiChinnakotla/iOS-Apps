//
//  User.swift
//  InClass03
//
//  Created by Kranthi Chinnakotla on 7/12/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import Foundation

class User{
    
    var user_Name = ""
    var user_Email = ""
    var user_Password = ""
    var user_Department = ""
}
