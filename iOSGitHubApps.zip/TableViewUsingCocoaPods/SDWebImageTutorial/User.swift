//
//  User.swift
//  SDWebImageTutorial
//
//  Created by Kranthi Chinnakotla on 7/19/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import Foundation

class User{
    
    var title: String? = nil
    var developer: String? = nil
    var imgSmall: String?
    var imgLarge: String?
    var price: Double = 0.0
    var releaseDate: String? = nil
    
    
}