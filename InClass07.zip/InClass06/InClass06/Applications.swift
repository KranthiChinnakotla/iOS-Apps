//
//  Applications.swift
//  InClass06
//
//  Created by Kranthi Chinnakotla on 7/21/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import Foundation
class Application {
    var categories: String?
    var title : String?
    var smallImage : String?
    var largeImage: String?
    var releaseDate : String?
    var artist : String?
    var summary: String?
    var price = 0.0
}