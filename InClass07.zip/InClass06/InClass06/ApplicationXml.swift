//
//  ApplicationXml.swift
//  InClass06
//
//  Created by Kranthi Chinnakotla on 7/26/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import Foundation


class ApplicationXml:NSObject,NSXMLParserDelegate{
    var appList = [Application]()
    var eName = String()
    var categories = String()
    var name = String()
    var smallImage = String()
    var largeImage: String?
    var releaseDate = String()
    var artist = String()
    var summary: String?
    var price = 0.0

    func parseXml(url: String,completion: (app:[Application])->Void) -> Void{
        let nprUrl = NSURL(string: url)
        let session = NSURLSession.sharedSession()
        if let parser = NSXMLParser(contentsOfURL: nprUrl!){
            parser.delegate = self
            if(!parser.parse()){
                let error = parser.parserError
                let line = parser.lineNumber
                let column = parser.columnNumber
                print("\(line), \(column), \(error?.localizedDescription)")
            }
            else{
                NSOperationQueue.mainQueue().addOperationWithBlock({
                    completion(app:  self.appList)
                })
            }
        }
    }
    
    
    func parser(parser: NSXMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String]) {
        
        eName = elementName
        
        if (elementName == "feed"){
            artist = String()
            name = String()
            
            
            releaseDate = String()
            //summary = String()
            categories = attributeDict["category"]!
            price = Double(attributeDict["price"]!)!
            
        }
        
        if (elementName == "squareImage"){
            smallImage = attributeDict["url"]!
        }
        
        if(elementName == "otherImage"){
            largeImage = attributeDict["url"]
        }
        

        
    }
    func parser(parser: NSXMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        
        if(elementName == "feed"){
            let feed = Application()
            feed.artist = artist
            feed.categories = categories
            feed.largeImage = largeImage
            feed.smallImage = smallImage
            feed.price = price
            feed.releaseDate = releaseDate
            feed.summary = summary
            feed.title = name
            
            appList.append(feed)
        }
        
    }
    
    func parser(parser: NSXMLParser, foundCharacters string: String) {
        
        let data = string.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
        
        if (!data.isEmpty){
            if(eName == "artist"){
                artist += data
            }else if(eName == "name"){
                name += data
            }else if(eName == "releaseDate"){
                releaseDate += data
            }
        }
        
    }
    
    func parser(parser: NSXMLParser, foundCDATA CDATABlock: NSData) {
        let sum = String(data: CDATABlock, encoding: NSUTF8StringEncoding)
            
            //String(CDATABlock: NSData!.self, encoding: NSUTF8StringEncoding);
        summary = sum
        
        
    }
    
}