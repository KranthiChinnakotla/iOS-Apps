//
//  Pictures.swift
//  InClass04b
//
//  Created by Kranthi Chinnakotla on 7/14/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import Foundation

struct  Pictures {
    static let animals = [
        0: "http://dev.theappsdr.com/lectures/inclass_http/index.php?pid=0",
        1: "http://dev.theappsdr.com/lectures/inclass_http/index.php?pid=1",
        2: "http://dev.theappsdr.com/lectures/inclass_http/index.php?pid=2",
        3: "http://dev.theappsdr.com/lectures/inclass_http/index.php?pid=3",
        4: "http://dev.theappsdr.com/lectures/inclass_http/index.php?pid=4",
        5: "http://dev.theappsdr.com/lectures/inclass_http/index.php?pid=5",
        6: "http://dev.theappsdr.com/lectures/inclass_http/index.php?pid=6",
        7: "http://dev.theappsdr.com/lectures/inclass_http/index.php?pid=7",
        8: "http://dev.theappsdr.com/lectures/inclass_http/index.php?pid=8",
        9: "http://dev.theappsdr.com/lectures/inclass_http/index.php?pid=9",
        10: "http://dev.theappsdr.com/lectures/inclass_http/index.php?pid=10",
        11: "http://dev.theappsdr.com/lectures/inclass_http/index.php?pid=11",
        12: "http://dev.theappsdr.com/lectures/inclass_http/index.php?pid=12",
        13: "http://dev.theappsdr.com/lectures/inclass_http/index.php?pid=13",
        14: "http://dev.theappsdr.com/lectures/inclass_http/index.php?pid=14",
        15: "http://dev.theappsdr.com/lectures/inclass_http/index.php?pid=15",
        16: "http://dev.theappsdr.com/lectures/inclass_http/index.php?pid=16",
        17: "http://dev.theappsdr.com/lectures/inclass_http/index.php?pid=17",
        18: "http://dev.theappsdr.com/lectures/inclass_http/index.php?pid=18",
        19: "http://dev.theappsdr.com/lectures/inclass_http/index.php?pid=19"]
}
