//
//  StoryTableViewController.swift
//  npradio
//
//  Created by Kranthi Chinnakotla on 7/21/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import UIKit
import SwiftyJSON
import SDWebImage
import AVFoundation
import Jukebox


class StoryTableViewController: UITableViewController,AVAudioPlayerDelegate,JukeboxDelegate {
    
    func jukeboxStateDidChange(state : Jukebox){
    }
    func jukeboxPlaybackProgressDidChange(jukebox : Jukebox){
        
    }
    func jukeboxDidLoadItem(jukebox : Jukebox, item : JukeboxItem){
        
    }
    func jukeboxDidUpdateMetadata(jukebox : Jukebox, forItem: JukeboxItem){
        
    }
    
    
    var player: AVAudioPlayer?
    var storylist = [NprStory]()
    var url: String?
    var jukeBox: Jukebox?
    
    var id: Int? {
        didSet{
            url = "http://api.npr.org/query?id=\(id!)&dateType=story&output=JSON&apiKey=MDI1NDE5NjQ1MDE0NjkxMTI5MDQ4ZmJjOA000"
        }
    }
    var playStatus = true
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let sourceUrl = NSURL(string: url!){
            if let data = try? NSData(contentsOfURL: sourceUrl, options: []){
                let json = JSON(data:data)
                
                let list = json["list"]
                let stories = list["story"]
                
                for story in stories.arrayValue{
                    
                    let nprstory = NprStory()
                    if let b = story["teaser"].dictionary{
                        guard let teaser = b["$text"]?.stringValue else{
                            continue
                        }
                        nprstory.description = teaser

                    }
                    
                    if let a = story["title"].dictionary{
                        guard let title = a["$text"]?.stringValue else{
                            continue
                        }
                        if let b = story["thumbnail"].dictionary{
                            if let c = b["medium"]?.dictionary{
                                guard let medimage = c["$text"]?.stringValue else{
                                    continue
                                }
                                nprstory.smallImageUrl = medimage
                            }
                        }
                        
                        
                        
                        nprstory.subTitle = title
                        
                    }
                    
                    if let aud = story["audio"].array{
                        for audio in aud{
                            
                            if let format = audio["format"].dictionary{
                                if let mp3 = format["mp3"]?.array{
                                    if let param = mp3[0].dictionary{
                                        let value = param["$text"]?.stringValue
                                        let val = value?.componentsSeparatedByString("?")
                                        nprstory.audioLink = val![0]
                                    }
                                }
                                
                            }
                        }
                    }
                    storylist.append(nprstory)
                }
                
            }
        }
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return storylist.count
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("customstory", forIndexPath: indexPath)
        
        // Configure the cell...
        
        (cell.viewWithTag(2) as? UILabel)?.text = storylist[indexPath.row].subTitle
        (cell.viewWithTag(200)as? UILabel)?.text = storylist[indexPath.row].description
        
        if(storylist[indexPath.row].smallImageUrl != nil){
            let url = NSURL(string: storylist[indexPath.row].smallImageUrl!)
            (cell.viewWithTag(1)as? UIImageView)?.sd_setImageWithURL(url)
        }else {
            (cell.viewWithTag(1)as? UIImageView)?.image = UIImage(named: "npr")
        }
        if let tCell = cell as? StoryTableViewCell{
            tCell.audioButton.tag = indexPath.row
            tCell.addButton.tag = indexPath.row
            tCell.addButton.addTarget(self, action: "addStories:", forControlEvents: .TouchUpInside)
            tCell.deleteButton.tag = indexPath.row
            tCell.deleteButton.addTarget(self, action: "deleteStories:", forControlEvents: .TouchUpInside)
        }
        
        
        
        
        
        
        return cell
    }
    
    
    func deleteStories(sender: UIButton){
        AppDelegate.playList?.remove(item: storylist[sender.tag].jukeBoxItem!)
        AppDelegate.trackList.removeLast()
    }
    
    func addStories(sender: UIButton){
        if let  audioUrl = storylist[sender.tag].audioLink{
            AppDelegate.playList?.append(item: JukeboxItem(URL: NSURL(string: audioUrl)!), loadingAssets: true)
            AppDelegate.trackList.append(storylist[sender.tag].subTitle!)
            storylist[sender.tag].jukeBoxItem = JukeboxItem(URL: NSURL(string: audioUrl)!)
            
            
        }
        
        
        
    }
    
    
    
    /*
     // Override to support conditional editing of the table view.
     override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
     if editingStyle == .Delete {
     // Delete the row from the data source
     tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
     } else if editingStyle == .Insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if(segue.identifier == "avkitsegue"){
            let aController = segue.destinationViewController as? AudioController
            if let button = sender as? UIButton{
                if let aurl = storylist[button.tag].audioLink{
                    aController!.audioUrl = aurl
                }
            }
            
            
        }
        
        if(segue.identifier == "playlistsegue"){
            let aController = segue.destinationViewController as? AudioController
            
            
            aController?.jukeBox = AppDelegate.playList
            
            }
        
    }
    
    
}




