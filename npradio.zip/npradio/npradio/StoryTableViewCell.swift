//
//  StoryTableViewCell.swift
//  npradio
//
//  Created by Kranthi Chinnakotla on 7/24/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import UIKit

class StoryTableViewCell: UITableViewCell {
    

    
    @IBOutlet weak var addButton: UIButton!

    @IBOutlet weak var audioButton: UIButton!
    
    
    @IBOutlet weak var deleteButton: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
