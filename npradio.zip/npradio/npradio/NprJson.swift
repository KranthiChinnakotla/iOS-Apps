//
//  NprJson.swift
//  npradio
//
//  Created by Kranthi Chinnakotla on 7/21/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import Foundation
class NprJson{
    
    var titles = [String]()
    var title = ""
    var npList = [NpRadio]()
    
    
    func parseJson(url: String,completion: (npr:[NpRadio])->Void) -> Void {
        let nprUrl = NSURL(string: url)
        let session = NSURLSession.sharedSession()
        var jsonObject : Dictionary<String,AnyObject>?
        let task = session.dataTaskWithURL(nprUrl!) { (data, response, error) in
            
            if (error != nil){
                print(error?.localizedDescription)
            }else{
                do {  jsonObject = try (NSJSONSerialization.JSONObjectWithData(data!, options: .MutableContainers)  as? Dictionary<String, AnyObject>) }
                catch{
                    
                    
                    
                    
                }
            }
            
            guard let root = jsonObject else {
               return
            }
            guard let items = root["item"] as? Array<AnyObject> else {
                return
            }
            
            for item in items {
                var npr = NpRadio()
                if let itemDict = item as? Dictionary<String,AnyObject>{
                    if let id = itemDict["id"] as? String{
                        npr.id = Int(id)
                    }
                    if let dict = itemDict["title"] as? Dictionary<String,String>{
                        //self.title = dict["$text"]!
                        npr.title = dict["$text"]
                    }
                }else {
                    continue
                }
                
                self.npList.append(npr)
                
             }
            
            NSOperationQueue.mainQueue().addOperationWithBlock({
                completion(npr:  self.npList)
            })
           
            
        }
        
        task.resume()
        
        
        
        
    }
    
}