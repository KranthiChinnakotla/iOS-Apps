//
//  NprStory.swift
//  npradio
//
//  Created by Kranthi Chinnakotla on 7/23/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import Foundation
import Jukebox
class NprStory{
    
    var subTitle: String?
    var smallImageUrl: String?
    var largeImageUrl: String?
    var audioLink: String?
    var description: String?
    var pubDate: String?
    var jukeBoxItem: JukeboxItem?
    
    
}