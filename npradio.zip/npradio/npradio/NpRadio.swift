//
//  NpRadio.swift
//  npradio
//
//  Created by Kranthi Chinnakotla on 7/21/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import Foundation
class NpRadio {
    var title:String?
    var id: Int?
    
}