//
//  AudioController.swift
//  npradio
//
//  Created by Kranthi Chinnakotla on 7/24/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation
import Jukebox

class AudioController: UIViewController,UITableViewDelegate,JukeboxDelegate,UITableViewDataSource {
    
    
    var avPlayer:AVPlayer?
    var avPlayerItem:AVPlayerItem?
    var jukeBox:Jukebox?
    var cond = true
    var audioUrl: String? {
        didSet{
            
        }
    }
    
    
    @IBOutlet weak var forwardButton: UIButton!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var playButton: UIButton!
    
    @IBAction func playButton(sender: UIButton) {
        
       
        
        if(cond){
         jukeBox?.play()
            playButton.setImage(UIImage(named: "Pause Filled-50"), forState: .Normal)
            cond = false
        }else if(!cond){
            jukeBox?.pause()
            playButton.setImage(UIImage(named: "Play Filled-50"), forState: .Normal)
            cond = true
            
        }
        
        
        
    }
    
    
    @IBAction func nextButton(sender: UIButton) {
        jukeBox?.playNext()
        
    }
    
    
    @IBAction func previousButton(sender: UIButton) {
        
        jukeBox?.playPrevious()
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return AppDelegate.trackList.count
        
    }
    
    func tableView(tableView: UITableView,
                     cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell{
        
    let cell = tableView.dequeueReusableCellWithIdentifier("internalplaylist",forIndexPath: indexPath)
        
        (cell.viewWithTag(100) as? UILabel)?.text = AppDelegate.trackList[indexPath.row]
        
        
        return cell
        
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }

    
    
    
    
    

    func jukeboxStateDidChange(state : Jukebox){
        if state.state == .Ready {
            playButton.setImage(UIImage(named: "Play Filled-50"), forState: .Normal)
        } else if state.state == .Loading  {
            playButton.setImage(UIImage(named: "Pause Filled-50"), forState: .Normal)
        } else {
            
            playButton.setImage(UIImage(named: state.state == .Paused ? "Play Filled-50" : "Pause Filled-50"), forState: .Normal)
        }
    }
    func jukeboxPlaybackProgressDidChange(jukebox : Jukebox){
        
    }
    func jukeboxDidLoadItem(jukebox : Jukebox, item : JukeboxItem){
        
    }
    func jukeboxDidUpdateMetadata(jukebox : Jukebox, forItem: JukeboxItem){
        
    }
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
       
        if let url = audioUrl{
            
        jukeBox = Jukebox(delegate: self, items: [JukeboxItem(URL: NSURL(string: url)!)])
            jukeBox?.play()
            playButton.setImage(UIImage(named: "Pause Filled-50"), forState: .Normal)
            cond = false

            
        }
        
        
        
        
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(true)
        
        jukeBox?.pause()
        
        
    }

    
    
    
}
