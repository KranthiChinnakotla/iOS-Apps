//
//  Users.swift
//  SampleFinal
//
//  Created by Kranthi Chinnakotla on 8/9/16.
//  Copyright © 2016 student. All rights reserved.
//

import Foundation
class Users{
    
    
    var name: String?
    var items: Int?
    var budget: Double?
    var imageUrl: String?
    var remainingBudget: Double?
    
}