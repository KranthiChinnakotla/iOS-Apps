//
//  GiftTableViewController.swift
//  SampleFinal
//
//  Created by student on 8/8/16.
//  Copyright © 2016 student. All rights reserved.
//

import UIKit
import SDWebImage
import Firebase
import MBProgressHUD

class GiftTableViewController: UITableViewController {
    var ref = FIRDatabase.database().reference()
    var index: String?
    var gifts = [Gifts]()
    var budget: Double?
    var totalPrice = 0.0
   
    @IBAction func unwindGift(segue: UIStoryboardSegue){
        let vc = segue.sourceViewController as! AddGiftTableViewController
        
        let selectedGift = vc.gifts[(vc.tableView.indexPathForSelectedRow?.row)!]
        if(budget! >= Double(selectedGift.price!)){
            let selectDict = ["name":selectedGift.giftName!,"image":selectedGift.image!,"price":selectedGift.price!] as Dictionary<String,AnyObject>
            ref.child(index!).childByAutoId().setValue(selectDict)
            index = vc.index
            ref.child((FIRAuth.auth()?.currentUser?.uid)!).child(index!).child("items").setValue(gifts.count)
            ref.child((FIRAuth.auth()?.currentUser?.uid)!).child(index!).child("budgetleft").setValue(budget! - totalPrice)
            
            

        }else{
            let alertCon = UIAlertController(title: "No Budget", message: "Add more budget", preferredStyle: .Alert)
            alertCon.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
            self.presentViewController(alertCon, animated: true, completion: nil)
        }
        

    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
        MBProgressHUD.showHUDAddedTo(self.view, animated: true)
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0)) {
            let query = self.ref.child(self.index!).queryOrderedByChild("price")
            query.observeEventType(.Value, withBlock: { (snapshot) in
                self.gifts.removeAll()
                
                for snaps in snapshot.children{
                    let gift = Gifts()
                    gift.giftName = (snaps.childSnapshotForPath("name").value as! String)
                    gift.price = (snaps.childSnapshotForPath("price").value as! Int)
                    gift.image = (snaps.childSnapshotForPath("image").value as! String)
                    self.gifts.append(gift)
                }
                self.tableView.reloadData()
            })
            /*  self.ref.child("Gifts").observeEventType(.Value, withBlock: { (snapshot) in
             self.gifts.removeAll()
             for snaps in snapshot.children{
             let gift = Gifts()
             gift.giftName = (snaps.childSnapshotForPath("gift").value as! String)
             gift.price = (snaps.childSnapshotForPath("price").value as! Int)
             gift.image = (snaps.childSnapshotForPath("imageUrl").value as! String)
             self.gifts.append(gift)
             }
             self.tableView.reloadData()
             })*/
            dispatch_async(dispatch_get_main_queue(), {
                MBProgressHUD.hideHUDForView(self.view, animated: true)
            })
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return gifts.count
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("giftcell", forIndexPath: indexPath)

        let url = NSURL(string: gifts[indexPath.row].image!)
        (cell.viewWithTag(101) as! UIImageView).sd_setImageWithURL(url!)
        (cell.viewWithTag(201) as! UILabel).text = gifts[indexPath.row].giftName
        (cell.viewWithTag(202) as! UILabel).text = String(gifts[indexPath.row].price!)
        // Configure the cell...
        totalPrice += Double(gifts[indexPath.row].price!)

        return cell
    }
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if(segue.identifier=="addgiftsegue"){
            let dc = segue.destinationViewController as! UINavigationController
            let vc = dc.topViewController as! AddGiftTableViewController
            vc.index = index
            vc.budget = budget! - totalPrice
        }
    }
    
    override func viewDidDisappear(animated: Bool) {
        super.viewDidDisappear(true)
       // let dict = ["items":gifts.count,"budgetleft":budget!-totalPrice]
        
    }
 

}
