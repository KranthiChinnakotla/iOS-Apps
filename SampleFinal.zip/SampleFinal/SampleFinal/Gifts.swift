//
//  Gifts.swift
//  SampleFinal
//
//  Created by student on 8/8/16.
//  Copyright © 2016 student. All rights reserved.
//

import Foundation
class Gifts  {
    var giftName: String?
    var price: Int?
    var image: String?
}