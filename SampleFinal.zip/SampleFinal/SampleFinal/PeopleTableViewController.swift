//
//  PeopleTableViewController.swift
//  SampleFinal
//
//  Created by student on 8/8/16.
//  Copyright © 2016 student. All rights reserved.
//

import UIKit
import Firebase
import MBProgressHUD



class PeopleTableViewController: UITableViewController {
    
    @IBAction func logOut(sender: UIBarButtonItem) {
        
        try! FIRAuth.auth()?.signOut()
         self.navigationController?.popViewControllerAnimated(true)
    }
    
    @IBAction func addPeople(sender: UIBarButtonItem) {
        
        
        
    }
    
    @IBAction func unwindFromAdd(segue: UIStoryboardSegue){
        
        
    }
    
    var name = [String]()
    var budget=[Double]()
    var items = [Int]()
    var indexes = [String]()
    var remainingBudget = [Double]()
    var imageUrl = [String]()
    var users = [Users]()
    
    var ref = FIRDatabase.database().reference()
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(true)
        self.tableView.reloadData()
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
      
        MBProgressHUD.showHUDAddedTo(self.view, animated: true)
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0)) { 
            self.ref.child((FIRAuth.auth()?.currentUser?.uid)!).observeEventType(.Value, withBlock: { (snapshot) in
                
                if let dict = snapshot.value! as? Dictionary<String,AnyObject>{
                    self.users.removeAll()
                    for key in dict.keys{
                        self.indexes.append(key)
                    }
                    for snaps in snapshot.children{
                         let user = Users()
                      /*  self.name.append((snaps.childSnapshotForPath("name").value as! String))
                        self.items.append((snaps.childSnapshotForPath("items").value as! Int))
                        self.budget.append((snaps.childSnapshotForPath("budget").value as! Double))
                        self.imageUrl.append(snaps.childSnapshotForPath("image").value as! String)
                        self.remainingBudget.append((snaps.childSnapshotForPath("budgetleft").value as! Double))*/
                        user.name = (snaps.childSnapshotForPath("name").value as! String)
                        user.items = (snaps.childSnapshotForPath("items").value as! Int)
                        user.budget = (snaps.childSnapshotForPath("budget").value as! Double)
                        user.imageUrl = (snaps.childSnapshotForPath("image").value as! String)
                        user.remainingBudget = (snaps.childSnapshotForPath("budgetleft").value as! Double)
                        self.users.append(user)
                    }
                    /* for vals in dict.values {
                     let diction = vals as! Dictionary<String,AnyObject>
                     self.name.append(diction["name"] as! String)
                     self.items.append(diction["items"] as! String)
                     self.budget.append(diction["budget"] as! String)
                     
                     
                     }*/
                    
                }
                
                
                self.tableView.reloadData()
            })
            
            dispatch_async(dispatch_get_main_queue(), { 
                MBProgressHUD.hideHUDForView(self.view, animated: true)
            })

        }
        
        
        
            
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        
        return users.count
    }

    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("peoplecell", forIndexPath: indexPath)
        
        (cell.viewWithTag(201) as! UILabel).text = users[indexPath.row].name
        (cell.viewWithTag(202) as! UILabel).text = "\(users[indexPath.row].items!) Gifts bought"
        (cell.viewWithTag(203) as! UILabel).text = "\(users[indexPath.row].remainingBudget!) / \(users[indexPath.row].budget!)"
        let url = NSURL(string: users[indexPath.row].imageUrl!)
        (cell.viewWithTag(101) as! UIImageView).sd_setImageWithURL(url!)
        if(users[indexPath.row].remainingBudget! < users[indexPath.row].budget!){
            (cell.viewWithTag(203) as! UILabel).textColor = UIColor.greenColor()
        }

        // Configure the cell...

        return cell
    }
 

    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

  
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
        if (segue.identifier=="giftsegue"){
            let vc = segue.destinationViewController as! GiftTableViewController
            //let vc = dc.topViewController as!
            vc.index = indexes[(tableView.indexPathForSelectedRow?.row)!]
            vc.budget = Double (users[(tableView.indexPathForSelectedRow?.row)!].remainingBudget!)
        }
    }
 

}
