//
//  ViewController.swift
//  SampleFinal
//
//  Created by student on 8/8/16.
//  Copyright © 2016 student. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
import MBProgressHUD


class ViewController: UIViewController {

    var uid: String?
    var isAnonymous: Bool?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    
    @IBOutlet weak var userName: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    
    @IBAction func createUser(sender: UIButton) {
        
        if let email = userName.text, pass = password.text{
            
            MBProgressHUD .showHUDAddedTo(self.view, animated: true)
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0), {
                
                
                
                FIRAuth.auth()?.createUserWithEmail(email, password: pass, completion: { (user, error) in
                    
                    
                    
                    
                    
                    if (error?.code != nil){
                        let atController = UIAlertController(title: "Error", message: error!.localizedDescription, preferredStyle: UIAlertControllerStyle.Alert)
                        atController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler:nil))
                        self.presentViewController(atController, animated: true, completion: nil)
                        
                    }else{
                        
                        
                        let atController = UIAlertController(title: "Success", message: "Created Successfully", preferredStyle: UIAlertControllerStyle.Alert)
                        
                        atController.addAction(UIAlertAction(title: "OK", style: .Default, handler: { (action) in
                            
                        }))
                        self.presentViewController(atController, animated: true, completion: nil)
                        }
                    
                })
                
                dispatch_async(dispatch_get_main_queue(), {
                    MBProgressHUD.hideHUDForView(self.view, animated: true)
                    
                    
                    
                    
                })
                
                
            })
            
        }
        
    }
    
    
    
    
    @IBAction func signIn(sender: UIButton) {
        
        
        userName.text = "a@a.com"
        password.text = "123456"
        
        
        
        
        guard let email = userName.text where userName.text! != "" else{
            let alertController = UIAlertController(title: "Invalid", message: "Email is empty", preferredStyle: .Alert)
            alertController.addAction(UIAlertAction(title: "ReEnter", style: .Default, handler: nil))
            self.presentViewController(alertController, animated: true, completion: nil)
            return
        }
        guard let pass = password.text where password.text! != "" else{
            let alertController = UIAlertController(title: "Invalid", message: "Password is empty", preferredStyle: .Alert)
            alertController.addAction(UIAlertAction(title: "ReEnter", style: .Default, handler: nil))
            self.presentViewController(alertController, animated: true, completion: nil)
            return
        }
        
        if (userName.text != nil && password.text != nil){
            MBProgressHUD.showHUDAddedTo(self.view, animated: true)
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0), {
                
                FIRAuth.auth()?.signInWithEmail(email, password: pass, completion: { (user, error) in
                    if (error?.code != nil){
                        let alertController = UIAlertController(title: "Failed SignIn", message: error!.localizedDescription, preferredStyle: .Alert)
                        alertController.addAction(UIAlertAction(title: "Dismiss", style: .Default, handler: nil))
                        self.presentViewController(alertController, animated: true, completion: nil)
                    }
                    else {
                        let alertController = UIAlertController(title: "OK", message: "Signed In Successfully", preferredStyle: .Alert)
                        alertController.addAction(UIAlertAction(title: "OK", style: .Default, handler: { (action) in
                            self.performSegueWithIdentifier("peoplesegue", sender: self)
                        }))
                        self.presentViewController(alertController, animated: true, completion: nil)
                        
                    }
                })
                
                dispatch_async(dispatch_get_main_queue(), {
                    MBProgressHUD.hideHUDForView(self.view, animated: true)
                    
                })
                
            })
        }
        
        
    }

}

