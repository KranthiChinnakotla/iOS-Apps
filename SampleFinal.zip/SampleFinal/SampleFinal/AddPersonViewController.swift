//
//  AddPersonViewController.swift
//  SampleFinal
//
//  Created by student on 8/8/16.
//  Copyright © 2016 student. All rights reserved.
//

import UIKit
import Firebase
import SDWebImage

class AddPersonViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    let alertController = UIAlertController(title: "Invalid", message: "ReEnter", preferredStyle: .Alert)
    var ref = FIRDatabase.database().reference()
    var urlString: String? = ""
    
    
    @IBOutlet weak var avatar: UIImageView!
    
    @IBOutlet weak var personName: UITextField!

    @IBOutlet weak var budget: UITextField!
    
    
    @IBAction func submitButton(sender: UIButton) {
        guard let a = personName.text where a != "" else{
            
            alertController.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
            self.presentViewController(alertController, animated: true, completion: nil)
            
            return
        }
        
        guard let b = Double(budget.text!) else {
            
            alertController.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
            self.presentViewController(alertController, animated: true, completion: nil)
            return
        }
        let person = ["name":a,"budget": b,"items":0,"budgetleft":b,"image":urlString!]
        
        
        ref.child((FIRAuth.auth()?.currentUser?.uid)!).childByAutoId().setValue(person)
        dismissViewControllerAnimated(true, completion: nil)
        
    }
    
    
    @IBAction func addImage(sender: UIButton) {
        
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.allowsEditing = true
        presentViewController(picker, animated: true, completion: nil)

    }
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        
        var selectedImag: UIImage?
        
        if let originalImage = info["UIImagePickerControllerOriginalImage"]{
            
            selectedImag = (originalImage as! UIImage)
            
        }else if let editImage = info["UIImagePickerControllerEditedImage"]{
            selectedImag = (editImage as! UIImage)
        }
        
        if let image = selectedImag {
            avatar.image = image
            
            let imageName = NSUUID().UUIDString
            
            let storageRef = FIRStorage.storage().referenceForURL("gs://samplefinal-e5ec2.appspot.com").child("profile_images").child("\(imageName).png")
            //.child("userImages.png")
            if let uploadData = UIImagePNGRepresentation(image){
                storageRef.putData(uploadData, metadata: nil, completion: { (metadata, error) in
                    if(error != nil){
                        let alertController = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: .Alert)
                        alertController.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
                        self.presentViewController(alertController, animated: true, completion: nil)
                    }
                    else
                    {
                        
                        self.urlString = metadata?.downloadURL()?.absoluteString
                      
                        
                    }
                    
                    
                    
                    
                    
                })
            }
            
            
            
            
            
        }
        
        
        dismissViewControllerAnimated(true, completion: nil)
        
        
        
        
    }
    
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        print("Canceleld picker")
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
