//
//  ViewController.swift
//  Communicator
//
//  Created by Kranthi Chinnakotla on 7/30/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import UIKit
import FirebaseAuth

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let email = "kranthi2@hotmail.com"
      /*  FIRAuth.auth()?.createUserWithEmail(email, password: "123456", completion: { (user, error) in
            
            //let user = ["provider":  user?.providerID,"email": email,"password":"1234"]
                
            
            
        if (error?.code != nil){
        let alertController = UIAlertController(title: "Error", message: error!.localizedDescription, preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler:nil))
            self.presentViewController(alertController, animated: true, completion: nil)
        }
            
               
            
                
            
            else{
            
            
                 let alertController = UIAlertController(title: "Error", message: "Created Successfully", preferredStyle: UIAlertControllerStyle.Alert)
            
                alertController.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
                self.presentViewController(alertController, animated: true, completion: nil)
            
            }
            
        })*/
        
        FIRAuth.auth()?.signInWithEmail(email, password: "123456", completion: { (user, error) in
            if (error?.code != nil){
                let alertController = UIAlertController(title: "Failed SignIn", message: error!.localizedDescription, preferredStyle: .Alert)
                alertController.addAction(UIAlertAction(title: "Dismiss", style: .Default, handler: nil))
                self.presentViewController(alertController, animated: true, completion: nil)
            }
            else {
                let alertController = UIAlertController(title: "OK", message: "Signed In Successfully", preferredStyle: .Alert)
                alertController.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
                self.presentViewController(alertController, animated: true, completion: nil)
            }
        })
        
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

