//
//  ViewController.swift
//  Communicator
//
//  Created by Kranthi Chinnakotla on 7/30/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import UIKit
import FirebaseAuth
import MBProgressHUD

class ViewController: UIViewController {
        
    @IBOutlet weak var emailTextField: UITextField!
    
    @IBOutlet weak var passwordText: UITextField!
    
    @IBAction func loginButton(sender: UIButton) {
        
        // emailTextField.text = "a@a.com"
        // passwordText.text = "123456"
        
        
        
                
                guard let email = emailTextField.text where emailTextField.text! != "" else{
                    let alertController = UIAlertController(title: "Invalid", message: "Email is empty", preferredStyle: .Alert)
                    alertController.addAction(UIAlertAction(title: "ReEnter", style: .Default, handler: nil))
                    self.presentViewController(alertController, animated: true, completion: nil)
                    return
                }
                guard let password = passwordText.text where passwordText.text! != "" else{
                    let alertController = UIAlertController(title: "Invalid", message: "Password is empty", preferredStyle: .Alert)
                    alertController.addAction(UIAlertAction(title: "ReEnter", style: .Default, handler: nil))
                    self.presentViewController(alertController, animated: true, completion: nil)
                    return
                }

                if (emailTextField.text != nil && passwordText.text != nil){
                    MBProgressHUD.showHUDAddedTo(self.view, animated: true)
                    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0), {
                        
                        FIRAuth.auth()?.signInWithEmail(email, password: password, completion: { (user, error) in
                            if (error?.code != nil){
                                let alertController = UIAlertController(title: "Failed SignIn", message: error!.localizedDescription, preferredStyle: .Alert)
                                alertController.addAction(UIAlertAction(title: "Dismiss", style: .Default, handler: nil))
                                self.presentViewController(alertController, animated: true, completion: nil)
                            }
                            else {
                                let alertController = UIAlertController(title: "OK", message: "Signed In Successfully", preferredStyle: .Alert)
                                alertController.addAction(UIAlertAction(title: "OK", style: .Default, handler: { (action) in
                                  //  let storyBoard = UIStoryboard(name: "Main", bundle: nil)
                                  //  let lVC = storyBoard.instantiateViewControllerWithIdentifier("eventstoryboard") as! EventTableViewController
                                  //  self.presentViewController(lVC, animated: true, completion: nil)
                                  self.performSegueWithIdentifier("eventsegue", sender: self)
                                    
                                }))
                                self.presentViewController(alertController, animated: true, completion: nil)
                            }
                        })
                        
                        dispatch_async(dispatch_get_main_queue(), {
                            MBProgressHUD.hideHUDForView(self.view, animated: true)
                        })
                        
                    })
                }
               
            
            
            
            
        
        
    }
    
    @IBAction func unwindCreateCancel (segue: UIStoryboardSegue){
        
    }
    @IBAction func unwindLogout (segue: UIStoryboardSegue){
        
        if(FIRAuth.auth()?.currentUser != nil){
            do { try FIRAuth.auth()?.signOut()}
                catch{
                    
                }
            
        }
        
    }
    
    override func viewDidAppear(animated: Bool) {
        if (FIRAuth.auth()?.currentUser) != nil{
          /*  let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            let lVC = storyBoard.instantiateViewControllerWithIdentifier("eventstoryboard") as! EventTableViewController
            self.presentViewController(lVC, animated: true, completion: nil)}*/
            
           // self.performSegueWithIdentifier("eventsegue", sender: nil)
        }
        
    }
    
    
override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    
   /* if(FIRAuth.auth()?.currentUser != nil){
        print("User active")
        do {try FIRAuth.auth()?.signOut()}
        catch {
            
        }
    }else{
        print("User signed out")
    }*/
        
        
        
        
        
        
        
        
                
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

