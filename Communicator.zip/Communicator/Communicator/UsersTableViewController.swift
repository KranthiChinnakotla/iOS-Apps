//
//  UsersTableViewController.swift
//  Communicator
//
//  Created by Kranthi Chinnakotla on 8/4/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import UIKit
import FirebaseDatabase
import Firebase
import SDWebImage
import MBProgressHUD

class UsersTableViewController: UITableViewController {
    
    let ref = FIRDatabase.database().reference()
    
    var users = [Users]()
    
    
    @IBAction func addUser(sender: UIBarButtonItem) {
    }
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        MBProgressHUD.showHUDAddedTo(self.view, animated: true)
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0)) {
            if(FIRAuth.auth()?.currentUser != nil){
                
                self.ref.child("users").observeEventType(.Value, withBlock: { (snapshot) in
                    //   let postDict = snapshot.value as! [String : AnyObject]
                    //let id = postDict.indexForKey(snapshot.key)
                    //	let val: FIRDataSnapshot
                    let enumerator = snapshot.children
                    
                    self.users.removeAll()
                    
                    while let child = enumerator.nextObject() as? FIRDataSnapshot{
                        if(child.key != FIRAuth.auth()?.currentUser?.uid){
                            
                            var user = Users()
                            
                            user.FirstName = (child.childSnapshotForPath("FirstName").value as? String)!
                            user.LastName =  (child.childSnapshotForPath("LastName").value as? String)!
                            user.photo = (child.childSnapshotForPath("photo").value as! String)
                            user.Email = (child.childSnapshotForPath("Email").value as! String)
                            user.sender = (FIRAuth.auth()?.currentUser?.displayName)
                            user.uid = (child.key)
                            self.users.append(user)
                            
                            
                            }
                        
                        }
                    self.tableView.reloadData()

                    
                    
                })
                
                
            }
            dispatch_async(dispatch_get_main_queue(), {
                MBProgressHUD.hideHUDForView(self.view, animated: true)
                })
            
        }

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return users.count
    }

    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("userscell", forIndexPath: indexPath)

        let url = NSURL(string: users[indexPath.row].photo!)
        (cell.viewWithTag(1) as! UIImageView).sd_setImageWithURL(url!)
        (cell.viewWithTag(2)as! UILabel).text = users[indexPath.row].FirstName! + users[indexPath.row].LastName!

        return cell
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if(segue.identifier == "userprofilesegue"){
            let pViewController = segue.destinationViewController as! ProfileViewController
            pViewController.others = "Yes"
            pViewController.otherUser = users[(tableView.indexPathForSelectedRow?.row)!]
           
        }
        
        
    }
    

}
