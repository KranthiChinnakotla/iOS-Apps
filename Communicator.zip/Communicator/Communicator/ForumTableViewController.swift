//
//  ForumTableViewController.swift
//  Communicator
//
//  Created by Kranthi Chinnakotla on 8/5/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import UIKit
import Firebase
import MBProgressHUD

class ForumTableViewController: UITableViewController {
    
     var ref = FIRDatabase.database().reference().child("Forums")
    var rootRef = FIRDatabase.database().reference()
    var users = [Users]()
    var indexes = [String]()
    var forMsgs = [String]()
    var forumUsers = [String]()
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
        
       
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0)) {
            if(FIRAuth.auth()?.currentUser != nil){
                
                self.ref.observeEventType(.Value, withBlock: { (snapshot) in
                    
                    //let id = postDict.indexForKey(snapshot.key)
                    //	let val: FIRDataSnapshot
                    
                   // let enumerator = snapshot.children
                    
                   // self.users.removeAll()
                    
                    if let postDict = snapshot.value as? [String : AnyObject]{
                        
                        self.indexes.removeAll()
                        self.forMsgs.removeAll()
                        for (key,value) in postDict{
                            let forumDict = value as! Dictionary<String,String>
                            for(_,val) in forumDict{
                                self.indexes.append(key)
                                self.forMsgs.append(val)
                            }
                            }
                        
                        
                        
                    }
                    
                    
                 
                self.tableView.reloadData()
                    
                    
                    
                })
                
                
            }
            dispatch_async(dispatch_get_main_queue(), {
                MBProgressHUD.hideHUDForView(self.view, animated: true)
            })
            
        }
        
        
        MBProgressHUD.showHUDAddedTo(self.view, animated: true)
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0)) {
            if(FIRAuth.auth()?.currentUser != nil){
                
                self.rootRef.child("users").observeEventType(.Value, withBlock: { (snapshot) in
                    //   let postDict = snapshot.value as! [String : AnyObject]
                    //let id = postDict.indexForKey(snapshot.key)
                    //	let val: FIRDataSnapshot
                    let enumerator = snapshot.children
                    
                    self.users.removeAll()
                    
                    while let child = enumerator.nextObject() as? FIRDataSnapshot{
                        
                            
                            var user = Users()
                            
                            user.FirstName = (child.childSnapshotForPath("FirstName").value as? String)!
                            user.LastName =  (child.childSnapshotForPath("LastName").value as? String)!
                            user.photo = (child.childSnapshotForPath("photo").value as! String)
                            user.Email = (child.childSnapshotForPath("Email").value as! String)
                            user.sender = (FIRAuth.auth()?.currentUser?.displayName)
                            user.uid = (child.key)
                            self.users.append(user)
                        
                        
                            
                            
                            
                        
                        
                    }
                    self.tableView.reloadData()
                    
                    
                    
                })
                
                
            }
            dispatch_async(dispatch_get_main_queue(), {
                MBProgressHUD.hideHUDForView(self.view, animated: true)
            })
            
        }

        
        
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return forMsgs.count
    }

    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("forumcell", forIndexPath: indexPath)

        // Configure the cell...
        if(users.count>0){
            for usr in users{
                if (indexes[indexPath.row] == usr.uid){
                    let url = NSURL(string: usr.photo!)
                    (cell.viewWithTag(101) as! UIImageView).sd_setImageWithURL(url!)
                    (cell.viewWithTag(201) as! UILabel).text = usr.FirstName! + usr.LastName!
                    (cell.viewWithTag(202) as! UILabel).text = forMsgs[indexPath.row]
                    if(indexes[indexPath.row] != FIRAuth.auth()?.currentUser?.uid){
                        (cell.viewWithTag(301) as! UIButton).hidden = true
                    }
                    if let button = cell.viewWithTag(301) as? UIButton{
                        button.addTarget(self, action: #selector(deleteMessage), forControlEvents: .TouchUpInside)
                        button.tag = indexPath.row
                        
                    }
                    
                }

            }
            
            
        }
        
        

        return cell
    }
    
    func deleteMessage(sender: UIButton!){
        let currentUserID = FIRAuth.auth()?.currentUser?.uid
        let index = indexes[sender.tag]
        self.ref.child("Forums").child(currentUserID!).child(index).removeValue()
        
    }

    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if(segue.identifier == "forumdetailsegue"){
            let fdViewController = segue.destinationViewController as! ForumDetailsViewController
            for usr in users{
            
                if(indexes[(tableView.indexPathForSelectedRow?.row)!] == usr.uid){
                    fdViewController.user = usr
                    fdViewController.forumMsg = forMsgs[(tableView.indexPathForSelectedRow?.row)!]
                }
            }
            
        }
    }
 

}
