//
//  DetailTableViewController.swift
//  Communicator
//
//  Created by Kranthi Chinnakotla on 8/2/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
import MBProgressHUD

class DetailTableViewController: UITableViewController {
    
    var notes = [String]()
    var indexes = [String]()
    var notesKey:String?
        var notesData: Dictionary<String,String>? = nil
    let ref = FIRDatabase.database().reference()
    
    
    @IBAction func addNotesDetails(sender: UIBarButtonItem) {
        
        let alert = UIAlertController(title: "New Note",
                                      message: "Enter new post text",
                                      preferredStyle: .Alert)
        
        let saveAction = UIAlertAction(title: "OK",
                                       style: .Default,
                                       handler: { (action:UIAlertAction) -> Void in
                                        let dat = NSDate()
                                        let formatter = NSDateFormatter()
                                        formatter.dateStyle = NSDateFormatterStyle.LongStyle
                                        formatter.timeStyle = .MediumStyle
                                        let stringDate = formatter.stringFromDate(dat)
                                        
                                        let textField = alert.textFields!.first
                                        self.notesData = ["NotesTaken": textField!.text!,"Date": stringDate]
                                        
                                        self.ref.child((FIRAuth.auth()?.currentUser?.uid)!).child("NotesTaken").child(self.notesKey!).childByAutoId().setValue(self.notesData)
                                        
                                        self.tableView.reloadData()
                                        
        })
        
        let cancelAction = UIAlertAction(title: "Cancel",
                                         style: .Default) { (action: UIAlertAction) -> Void in
        }
        
        alert.addTextFieldWithConfigurationHandler {
            (textField: UITextField) -> Void in
        }
        
        alert.addAction(saveAction)
        alert.addAction(cancelAction)
        
        presentViewController(alert,
                              animated: true,
                              completion: nil)
        

        
    }
    
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        if(notesKey != nil){
            
            MBProgressHUD.showHUDAddedTo(self.view, animated: true)
            
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0), {
                self.ref.child((FIRAuth.auth()?.currentUser?.uid)!).child("NotesTaken").child(self.notesKey!).observeEventType(.Value, withBlock: { (snapshot) in
                    //let postDict = snapshot.value as! [String : AnyObject]
                    //let id = postDict.indexForKey(snapshot.key)
                    //	let val: FIRDataSnapshot
                    let enumerator = snapshot.children
                    self.notes.removeAll()
                    while let child = enumerator.nextObject() as? FIRDataSnapshot{
                        self.notes.append((child.childSnapshotForPath("NotesTaken").value as? String)!)
                        self.indexes.append(child.key)
                        
                        
                    }
                    self.tableView.reloadData()
                    
                })
                
                dispatch_async(dispatch_get_main_queue(), {
                    MBProgressHUD.hideHUDForView(self.view, animated: true)
                    
                })
                
            })
            
           
            
        }
       

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return notes.count
    }

    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("detailcell", forIndexPath: indexPath)

        let dat = NSDate()
        let formatter = NSDateFormatter()
        formatter.dateStyle = NSDateFormatterStyle.LongStyle
        formatter.timeStyle = .MediumStyle
        let stringDate = formatter.stringFromDate(dat)
        (cell.viewWithTag(102) as? UILabel)?.text = stringDate
        
        
        // Configure the cell...
        (cell.viewWithTag(101) as? UILabel)?.text = notes[indexPath.row]
        (cell.viewWithTag(103) as? UIButton)?.addTarget(self, action: #selector(deleteS), forControlEvents: .TouchUpInside)
        (cell.viewWithTag(103) as? UIButton )?.tag = indexPath.row
        

        return cell
    }
    
    func deleteS(sender: UIButton){
        
        ref.child((FIRAuth.auth()?.currentUser?.uid)!).child("NotesTaken").child(self.notesKey!).child(indexes[sender.tag]).removeValue()
        
        self.tableView.reloadData()
        
    }

    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
