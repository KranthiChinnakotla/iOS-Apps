//
//  Messages.swift
//  Communicator
//
//  Created by Kranthi Chinnakotla on 8/5/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import Foundation
class Messages {
    var message: String?
    var photoUrl: String?
    var read: String?
    var sender: String?
    var msgKey: String?
}
