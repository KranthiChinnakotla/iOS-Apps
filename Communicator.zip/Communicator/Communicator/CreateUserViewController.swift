//
//  CreateUserViewController.swift
//  Communicator
//
//  Created by Kranthi Chinnakotla on 8/1/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import UIKit
import FirebaseAuth

class CreateUserViewController: UIViewController {
    
    
    
    @IBOutlet weak var firstName: UITextField!
    
    @IBOutlet weak var lastName: UITextField!
    
    
    
    @IBOutlet weak var emailText: UITextField!
    
    
    @IBOutlet weak var passwordText: UITextField!
    
    
    @IBOutlet weak var confirmPasswordText: UITextField!
    
    
    @IBAction func submitButton(sender: UIButton) {
        
        let alertController = UIAlertController(title: "Incorrect Details", message: "reenter the details", preferredStyle: .Alert)
        alertController.addAction(UIAlertAction(title: "ReEnter", style: .Default, handler: nil))
        guard let fName = firstName.text else {
            self.presentViewController(alertController, animated: true, completion: nil)
            return
        }
        guard let lName = lastName.text else {
            self.presentViewController(alertController, animated: true, completion: nil)
            return
        }
        guard let email = emailText.text else {
            self.presentViewController(alertController, animated: true, completion: nil)
            return
        }
        guard let password = passwordText.text else {
            self.presentViewController(alertController, animated: true, completion: nil)
            return
        }
        guard let cPassword = confirmPasswordText.text else {
            self.presentViewController(alertController, animated: true, completion: nil)
            return
        }
        
        if cPassword == password {
            FIRAuth.auth()?.createUserWithEmail(email, password: cPassword, completion: { (user, error) in
                
                //let user = ["provider":  user?.providerID,"email": email,"password":"1234"]
                
                
                
                if (error?.code != nil){
                    let atController = UIAlertController(title: "Error", message: error!.localizedDescription, preferredStyle: UIAlertControllerStyle.Alert)
                    atController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler:nil))
                    self.presentViewController(atController, animated: true, completion: nil)
                }
                    
                    
                    
                    
                    
                else{
                    
                    
                    let atController = UIAlertController(title: "Error", message: "Created Successfully", preferredStyle: UIAlertControllerStyle.Alert)
                    
                    atController.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
                    self.presentViewController(atController, animated: true, completion: nil)
                    
                }
                
            })
            
            
            
        }else{
            let aController = UIAlertController(title: "Confirm Passoword", message: "Password and Confirm Password not matching", preferredStyle: .Alert)
            aController.addAction(UIAlertAction(title: "ReEnter", style: .Default, handler: nil))
            self.presentViewController(aController, animated: true, completion: nil)
            
        }
        
        
        
        
        
        
    }
    
    
    @IBAction func cancelButton(sender: UIButton) {
        
        
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
