//
//  CreateUserViewController.swift
//  Communicator
//
//  Created by Kranthi Chinnakotla on 8/1/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import UIKit
import FirebaseAuth
import MBProgressHUD
import Firebase
import FirebaseDatabase

class CreateUserViewController: UIViewController {
    
    
    
    @IBOutlet weak var firstName: UITextField!
    
    @IBOutlet weak var lastName: UITextField!
    
    
    
    @IBOutlet weak var emailText: UITextField!
    
    
    @IBOutlet weak var passwordText: UITextField!
    
    
    @IBOutlet weak var confirmPasswordText: UITextField!
    
//    var count = 0
    
    @IBAction func submitButton(sender: UIButton) {
        
        let alertController = UIAlertController(title: "Incorrect Details", message: "reenter the details", preferredStyle: .Alert)
        alertController.addAction(UIAlertAction(title: "ReEnter", style: .Default, handler: nil))
        guard let fName = firstName.text else {
            self.presentViewController(alertController, animated: true, completion: nil)
            return
        }
        guard let lName = lastName.text else {
            self.presentViewController(alertController, animated: true, completion: nil)
            return
        }
        guard let email = emailText.text else {
            self.presentViewController(alertController, animated: true, completion: nil)
            return
        }
        guard let password = passwordText.text else {
            self.presentViewController(alertController, animated: true, completion: nil)
            return
        }
        guard let cPassword = confirmPasswordText.text else {
            self.presentViewController(alertController, animated: true, completion: nil)
            return
        }
        
        if cPassword == password {
            MBProgressHUD .showHUDAddedTo(self.view, animated: true)
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0), {
               
                
                
                FIRAuth.auth()?.createUserWithEmail(email, password: cPassword, completion: { (user, error) in
                    
                    
                    
                    
                    
                    if (error?.code != nil){
                        let atController = UIAlertController(title: "Error", message: error!.localizedDescription, preferredStyle: UIAlertControllerStyle.Alert)
                        atController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler:nil))
                        self.presentViewController(atController, animated: true, completion: nil)
                        
                    }else{
                        
                        
                        let atController = UIAlertController(title: "Success", message: "Created Successfully", preferredStyle: UIAlertControllerStyle.Alert)
                        
                        atController.addAction(UIAlertAction(title: "OK", style: .Default, handler: { (action) in
                            
                            let url = NSURL(string: "http://culttt.com/wp-content/uploads/2011/11/vanity-url.jpg")
                            let changeRequest = user?.profileChangeRequest()
                            changeRequest?.displayName = fName + lName
                            changeRequest?.photoURL = url
                            
                            changeRequest?.commitChangesWithCompletion({ (error) in
                                if (error != nil){
                                    print(error?.localizedDescription)
                                }
                            })
                            //let storyBoard = UIStoryboard(name: "Main", bundle: nil)
                            //let lVC = storyBoard.instantiateViewControllerWithIdentifier("eventstoryboard") as! EventTableViewController
                            //self.presentViewController(lVC, animated: true, completion: nil)
                            //self.performSegueWithIdentifier("createsegue", sender: nil)

                        }))
                        self.presentViewController(atController, animated: true, completion: nil)
                        let ref = FIRDatabase.database().reference()
                        let userData = ["FirstName": fName,"LastName": lName,"Email":email, "photo": "http://culttt.com/wp-content/uploads/2011/11/vanity-url.jpg"] as Dictionary<String,String>
                        let currentuser = FIRAuth.auth()?.currentUser
                        
                        ref.child("users").child((currentuser?.uid)!).setValue(userData)
                      //  self.count = 1
                        
                        
                        
                        
                    }
                    
                })
                
                dispatch_async(dispatch_get_main_queue(), { 
                    MBProgressHUD.hideHUDForView(self.view, animated: true)
                    
                
                    

                })
                
                
            })
           
            
            
            
        }else{
            let aController = UIAlertController(title: "Confirm Passoword", message: "Password and Confirm Password not matching", preferredStyle: .Alert)
            aController.addAction(UIAlertAction(title: "ReEnter", style: .Default, handler: nil))
            self.presentViewController(aController, animated: true, completion: nil)
            
        }
        
        
        
        
        
        
    }
    
    
    @IBAction func cancelButton(sender: UIButton) {
        
        
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
