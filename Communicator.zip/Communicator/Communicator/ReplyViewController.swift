//
//  ReplyViewController.swift
//  Communicator
//
//  Created by Kranthi Chinnakotla on 8/5/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import UIKit
import Firebase
import SDWebImage
import MBProgressHUD

class ReplyViewController: UIViewController,UIPickerViewDataSource,UIPickerViewDelegate {
    
    var msgs:Messages?
    var msgUser: Users?
    var msgDetails : Dictionary<String,String>?
    
    @IBOutlet weak var cancel: UIButton!
    

    @IBOutlet weak var submit: UIButton!
    
    
    @IBOutlet weak var messageArea: UITextField!
    
    @IBOutlet weak var pickerView: UIPickerView!
    
    
    @IBAction func cancelButton(sender: UIButton) {
        dismissViewControllerAnimated(true, completion: nil)
        
    }
    
    
    @IBAction func submitButton(sender: UIButton) {
        
        
        
        if let message = messageArea.text{
            
            msgDetails = ["sender":(msgUser?.sender)!,"msg":message,"senderPhoto":(currentUser!.photo)!,"read":"no"]
            ref.child("users").child(msgUser!.uid!).child("messages").childByAutoId().setValue(msgDetails)
            let alControl = UIAlertController(title: "Message  ", message: "Sent Successfully", preferredStyle: .Alert)
            alControl.addAction(UIAlertAction(title: "OK", style: .Default, handler: { (action) in
                self.messageArea.text = ""
            }))
            
            self.presentViewController(alControl, animated: true, completion: nil)
            
            
        }else{
            let alControl = UIAlertController(title: "Empty ", message: "Empty message", preferredStyle: .Alert)
            alControl.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
            self.presentViewController(alControl, animated: true, completion: nil)
            
        }

        
        
    }
    
    
    var users = [Users]()
    var currentUser: Users?
    var ref = FIRDatabase.database().reference()
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return users.count;
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return users[row].FirstName! + users[row].LastName!
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        msgUser = users[row]
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.pickerView.dataSource = self
        self.pickerView.delegate = self
        
        MBProgressHUD.showHUDAddedTo(self.view, animated: true)
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0)) {
            if(FIRAuth.auth()?.currentUser != nil){
                
                self.ref.child("users").observeEventType(.Value, withBlock: { (snapshot) in
                    //   let postDict = snapshot.value as! [String : AnyObject]
                    //let id = postDict.indexForKey(snapshot.key)
                    //	let val: FIRDataSnapshot
                    let enumerator = snapshot.children
                    
                    self.users.removeAll()
                    
                    while let child = enumerator.nextObject() as? FIRDataSnapshot{
                        if(child.key != FIRAuth.auth()?.currentUser?.uid){
                            
                            var user = Users()
                            
                            user.FirstName = (child.childSnapshotForPath("FirstName").value as? String)!
                            user.LastName =  (child.childSnapshotForPath("LastName").value as? String)!
                            user.photo = (child.childSnapshotForPath("photo").value as! String)
                            user.Email = (child.childSnapshotForPath("Email").value as! String)
                            user.sender = (FIRAuth.auth()?.currentUser?.displayName)
                            user.uid = (child.key)
                            self.users.append(user)
                            
                            
                        }else if(child.key == FIRAuth.auth()?.currentUser?.uid){
                            
                            self.currentUser = Users()
                            self.currentUser!.FirstName = (child.childSnapshotForPath("FirstName").value as? String)!
                            self.currentUser!.LastName =  (child.childSnapshotForPath("LastName").value as? String)!
                            self.currentUser!.photo = (child.childSnapshotForPath("photo").value as! String)
                            self.currentUser!.Email = (child.childSnapshotForPath("Email").value as! String)
                            self.currentUser!.sender = (FIRAuth.auth()?.currentUser?.displayName)
                            self.currentUser!.uid = (child.key)
                        }
                        
                    }
                    self.pickerView.reloadAllComponents()
                    
                    
                    
                })
                
                
            }
            dispatch_async(dispatch_get_main_queue(), {
                MBProgressHUD.hideHUDForView(self.view, animated: true)
            })
            
        }


        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
