//
//  ProfileViewController.swift
//  Communicator
//
//  Created by Kranthi Chinnakotla on 8/3/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import UIKit
import Firebase
import MBProgressHUD
import FirebaseDatabase
import SDWebImage

class ProfileViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    let ref = FIRDatabase.database().reference()
    
    var otherUser:Users?
    var others:String?
    
    @IBOutlet weak var imageView: UIImageView!
    
    
    @IBOutlet weak var fullName: UITextField!
    
    
    @IBOutlet weak var pImage: UIButton!
    
    @IBOutlet weak var email: UITextField!
    @IBAction func unwindCancel(segue: UIStoryboardSegue){
        
    }
    @IBOutlet weak var composeButton: UIBarButtonItem!
    @IBAction func pickImage(sender: UIButton) {
        
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.allowsEditing = true
        presentViewController(picker, animated: true, completion: nil)
        }
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        
        var selectedImage: UIImage?
        
        if let originalImage = info["UIImagePickerControllerOriginalImage"]{
            
         selectedImage = (originalImage as! UIImage)
            
        }else if let editImage = info["UIImagePickerControllerEditedImage"]{
            selectedImage = (editImage as! UIImage)
        }
        
        if let image = selectedImage {
            imageView.image = image
            
           let imageName = NSUUID().UUIDString
            
            let storageRef = FIRStorage.storage().referenceForURL("gs://projectmsg-11153.appspot.com").child("profile_images").child("\(imageName).png")
                //.child("userImages.png")
            if let uploadData = UIImagePNGRepresentation(image){
                storageRef.putData(uploadData, metadata: nil, completion: { (metadata, error) in
                    if(error != nil){
                        let alertController = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: .Alert)
                        alertController.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
                        self.presentViewController(alertController, animated: true, completion: nil)
                    }
                    else
                    {
                        
                        self.ref.child("users").child((FIRAuth.auth()?.currentUser?.uid)!).child("photo").setValue(metadata?.downloadURL()?.absoluteString)
                       // let changeRequest = (FIRAuth.auth()?.currentUser)?.profileChangeRequest()
                        //let url = NSURL(string: (metadata?.downloadURL()?.absoluteString)!)
                        //self.imageView.sd_setImageWithURL(url!)
                        //changeRequest?.photoURL = url!
                        
                    }
                    
                    
                    
                    
                    
                })
              }
            
           
            
            
            
        }
        
        
        dismissViewControllerAnimated(true, completion: nil)
        
        
        
        
    }
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        print("Canceleld picker")
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /*dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0)) {
            if(FIRAuth.auth()?.currentUser != nil){
                
            }
            dispatch_async(dispatch_get_main_queue(), {
                MBProgressHUD.hideHUDForView(self.view, animated: true)
            })
        }*/
        
        if(others != nil){
            pImage.hidden = true
            composeButton.enabled = true
            let s = (otherUser?.FirstName)! + (otherUser?.LastName)!
            self.fullName.text = s
            self.email.text = otherUser?.Email
            let url = NSURL(string: (otherUser?.photo)!)
            self.imageView.sd_setImageWithURL(url)
        }else{
            composeButton.enabled = false
            MBProgressHUD.showHUDAddedTo(self.view, animated: true)
            
            let user = FIRAuth.auth()?.currentUser
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0)) {
                if(FIRAuth.auth()?.currentUser != nil){
                    
                    self.ref.child("users").observeEventType(.Value, withBlock: { (snapshot) in
                        //   let postDict = snapshot.value as! [String : AnyObject]
                        //let id = postDict.indexForKey(snapshot.key)
                        //	let val: FIRDataSnapshot
                        let enumerator = snapshot.children
                        
                        
                        while let child = enumerator.nextObject() as? FIRDataSnapshot{
                            if(child.key == FIRAuth.auth()?.currentUser?.uid){
                                
                                
                                
                                
                                if let purl = NSURL(string:(child.childSnapshotForPath("photo").value as! String)){
                                    
                                    
                                    self.imageView.sd_setImageWithURL(purl)}
                                else{
                                    
                                    self.imageView.sd_setImageWithURL(user?.photoURL)
                                }
                                
                                
                                
                            }
                            
                        }
                        
                        
                        
                        
                    })
                    
                    
                }
                dispatch_async(dispatch_get_main_queue(), {
                    MBProgressHUD.hideHUDForView(self.view, animated: true)
                    let s = user?.displayName
                    self.fullName.text = s
                    self.email.text = user?.email
                    
                    
                    
                })
                
                
                // Do any additional setup after loading the view.
            }
        }
        

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if(segue.identifier == "messagesegue"){
            let mViewController = segue.destinationViewController as! MessageViewController
            mViewController.msgUser = otherUser
        }
    }
 

}
