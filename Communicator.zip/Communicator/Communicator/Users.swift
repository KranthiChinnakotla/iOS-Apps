//
//  Users.swift
//  Communicator
//
//  Created by Kranthi Chinnakotla on 8/4/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import Foundation

class Users {
    var FirstName:String?
    var photo:String?
    var LastName: String?
    var Email: String?
    var uid: String?
    var sender: String?
    
}