//
//  MessageViewController.swift
//  Communicator
//
//  Created by Kranthi Chinnakotla on 8/5/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import UIKit
import Firebase
import SDWebImage
import MBProgressHUD


class MessageViewController: UIViewController {
    var msgUser: Users?
    var currentUser: Users?
    var ref = FIRDatabase.database().reference()
    var msgDetails: Dictionary<String,String>?
    
    @IBAction func cancelButton(sender: UIButton) {
    }

    @IBAction func submitButton(sender: UIButton) {
        
        if let message = messageArea.text{
            
            msgDetails = ["sender":(msgUser?.sender)!,"msg":message,"senderPhoto":(currentUser!.photo)!,"read":"no"]
            ref.child("users").child(msgUser!.uid!).child("messages").childByAutoId().setValue(msgDetails)
            let alControl = UIAlertController(title: "Message  ", message: "Sent Successfully", preferredStyle: .Alert)
            alControl.addAction(UIAlertAction(title: "OK", style: .Default, handler: { (action) in
                self.messageArea.text = ""
            }))
            
            self.presentViewController(alControl, animated: true, completion: nil)

            
        }else{
            let alControl = UIAlertController(title: "Empty ", message: "Empty message", preferredStyle: .Alert)
            alControl.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
            self.presentViewController(alControl, animated: true, completion: nil)
            
        }
        
    }
    
    
    @IBOutlet weak var imageView: UIImageView!
    
    
    @IBOutlet weak var userTitle: UILabel!
    
    
    @IBOutlet weak var messageArea: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userTitle.text = (msgUser?.FirstName)! + (msgUser?.LastName)!
        let url = NSURL(string: (msgUser?.photo)!)
        imageView.sd_setImageWithURL(url)
        
        
        MBProgressHUD.showHUDAddedTo(self.view, animated: true)
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0)) {
            if(FIRAuth.auth()?.currentUser != nil){
                
                self.ref.child("users").observeEventType(.Value, withBlock: { (snapshot) in
                    //   let postDict = snapshot.value as! [String : AnyObject]
                    //let id = postDict.indexForKey(snapshot.key)
                    //	let val: FIRDataSnapshot
                    let enumerator = snapshot.children
                    
                   
                    
                    while let child = enumerator.nextObject() as? FIRDataSnapshot{
                        if(child.key == FIRAuth.auth()?.currentUser?.uid){
                            
                           self.currentUser = Users()
                            
                            self.currentUser!.FirstName = (child.childSnapshotForPath("FirstName").value as? String)!
                            self.currentUser!.LastName =  (child.childSnapshotForPath("LastName").value as? String)!
                            self.currentUser!.photo = (child.childSnapshotForPath("photo").value as! String)
                            self.currentUser!.Email = (child.childSnapshotForPath("Email").value as! String)
                            //user.sender = (FIRAuth.auth()?.currentUser?.displayName)
                            //user.uid = (child.key)
                            
                            
                            
                        }
                        
                    }
                    
                    
                    
                    
                })
                
                
            }
            dispatch_async(dispatch_get_main_queue(), {
                MBProgressHUD.hideHUDForView(self.view, animated: true)
            })
            
        }

        
        //print(msgUser?.uid)

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if(segue.identifier == "msgdetailsegue"){
            let mdController = segue.destinationViewController as! MessageDetailViewController
           // mdController.users = msgUser
            //mdController.msg = messageArea.text!
            
            
        }
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
 

}
