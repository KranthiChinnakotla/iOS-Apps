//
//  InboxTableViewController.swift
//  Communicator
//
//  Created by Kranthi Chinnakotla on 8/5/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import UIKit
import Firebase
import SDWebImage
import MBProgressHUD



class InboxTableViewController: UITableViewController {
    
    var msgs = [Messages]()
    
var ref = FIRDatabase.database().reference()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
        MBProgressHUD.showHUDAddedTo(self.view, animated: true)
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0)) {
            if(FIRAuth.auth()?.currentUser != nil){
                let currentUserID = FIRAuth.auth()?.currentUser?.uid
                self.ref.child("users").child(currentUserID!).child("messages").observeEventType(.Value, withBlock: { (snapshot) in
                    //   let postDict = snapshot.value as! [String : AnyObject]
                    //let id = postDict.indexForKey(snapshot.key)
                    //	let val: FIRDataSnapshot
                    let enumerator = snapshot.children
                    
                    self.msgs.removeAll()
                    
                    while let child = enumerator.nextObject() as? FIRDataSnapshot{
                        if(child.key != FIRAuth.auth()?.currentUser?.uid){
                            
                            let msg = Messages()
                            
                            msg.message = (child.childSnapshotForPath("msg").value as? String)!
                            msg.photoUrl =  (child.childSnapshotForPath("senderPhoto").value as? String)!
                            msg.read = (child.childSnapshotForPath("read").value as! String)
                            msg.sender = (child.childSnapshotForPath("sender").value as! String)
                            //user.sender = (FIRAuth.auth()?.currentUser?.displayName)
                            msg.msgKey = (child.key)
                            self.msgs.append(msg)
                            
                            
                        }
                        
                    }
                    self.tableView.reloadData()
                    
                    
                    
                })
                
                
            }
            dispatch_async(dispatch_get_main_queue(), {
                MBProgressHUD.hideHUDForView(self.view, animated: true)
            })
            
        }
        
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return msgs.count
    }

    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("inboxcell", forIndexPath: indexPath)

        // Configure the cell...
        let url = NSURL(string: msgs[indexPath.row].photoUrl!)
        (cell.viewWithTag(101) as! UIImageView).sd_setImageWithURL(url!)
        (cell.viewWithTag(201) as! UILabel).text = msgs[indexPath.row].sender
        (cell.viewWithTag(202) as! UILabel).text = msgs[indexPath.row].message
        if(msgs[indexPath.row].read == "yes"){
            (cell.viewWithTag(301) as! UIButton).hidden = true
        }
        if let button = cell.viewWithTag(302) as? UIButton{
            button.addTarget(self, action: #selector(deleteMessage), forControlEvents: .TouchUpInside)
            button.tag = indexPath.row

        }
        
        return cell
    }
    
    func deleteMessage(sender: UIButton!){
        let currentUserID = FIRAuth.auth()?.currentUser?.uid
        let readUser = msgs[sender.tag]
        self.ref.child("users").child(currentUserID!).child("messages").child(readUser.msgKey!).removeValue()
        
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if(segue.identifier == "msgdetailsegue"){
            let mdController = segue.destinationViewController as! MessageDetailViewController
           mdController.users = msgs[(tableView.indexPathForSelectedRow?.row)!]
            let readUser = msgs[(tableView.indexPathForSelectedRow?.row)!]
            let currentUserID = FIRAuth.auth()?.currentUser?.uid
             self.ref.child("users").child(currentUserID!).child("messages").child(readUser.msgKey!).child("read").setValue("yes")
            
            
        }
    }
 

}
