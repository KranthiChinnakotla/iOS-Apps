//
//  ForumDetailsViewController.swift
//  Communicator
//
//  Created by Kranthi Chinnakotla on 8/5/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import UIKit
import Firebase
import SDWebImage
import MBProgressHUD

class ForumDetailsViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    var cell:UITableViewCell?
    var ref = FIRDatabase.database().reference()
    var urlString: String? = ""
    var coments: Dictionary<String,String>?
    var comments = [String]()
    var dictComments:[Dictionary<String,String>]?
    
    @IBOutlet weak var profileImageView: UIImageView!
    
    
    
    @IBOutlet weak var forumTitle: UILabel!
    
    @IBOutlet weak var forumMessage: UILabel!
    
    
    @IBOutlet weak var commentsEdit: UITextField!

    @IBOutlet weak var selectedImage: UIImageView!
    
    @IBAction func postButton(sender: UIButton) {
        
        if let coms = commentsEdit.text{
            
            coments = ["comts": coms,"image": urlString!]
            self.ref.child("comments").child((FIRAuth.auth()?.currentUser?.uid)!).childByAutoId().child("coms").setValue(coments)
        }
    }
    
    
    @IBAction func addPhoto(sender: UIButton) {
        
        
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.allowsEditing = true
        presentViewController(picker, animated: true, completion: nil)

    }
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        
        var selectedImag: UIImage?
        
        if let originalImage = info["UIImagePickerControllerOriginalImage"]{
            
            selectedImag = (originalImage as! UIImage)
            
        }else if let editImage = info["UIImagePickerControllerEditedImage"]{
            selectedImag = (editImage as! UIImage)
        }
        
        if let image = selectedImag {
            selectedImage.image = image
            
            let imageName = NSUUID().UUIDString
            
            let storageRef = FIRStorage.storage().referenceForURL("gs://projectmsg-11153.appspot.com").child("profile_images").child("\(imageName).png")
            //.child("userImages.png")
            if let uploadData = UIImagePNGRepresentation(image){
                storageRef.putData(uploadData, metadata: nil, completion: { (metadata, error) in
                    if(error != nil){
                        let alertController = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: .Alert)
                        alertController.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
                        self.presentViewController(alertController, animated: true, completion: nil)
                    }
                    else
                    {
                        
                        self.urlString = metadata?.downloadURL()?.absoluteString
                        
                     // self.ref.child("comments").child((FIRAuth.auth()?.currentUser?.uid)!).childByAutoId().child("photo").setValue(metadata?.downloadURL()?.absoluteString)
                        // let changeRequest = (FIRAuth.auth()?.currentUser)?.profileChangeRequest()
                        //let url = NSURL(string: (metadata?.downloadURL()?.absoluteString)!)
                        //self.imageView.sd_setImageWithURL(url!)
                        //changeRequest?.photoURL = url!
                        
                    }
                    
                    
                    
                    
                    
                })
            }
            
            
            
            
            
        }
        
        
        dismissViewControllerAnimated(true, completion: nil)
        
        
        
        
    }
    
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        print("Canceleld picker")
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    @IBOutlet weak var tableView: UITableView!
    
    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
            return 0
    
        
    
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 0
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        cell = tableView.dequeueReusableCellWithIdentifier("innercell", forIndexPath: indexPath)
        //(cell?.viewWithTag(201) as! UILabel).text = comments[indexPath.row]
        
        
        return cell!
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        
        forumTitle.text = (user?.FirstName)! + (user?.LastName)!
        forumMessage.text = forumMsg
        let url = NSURL(string:(user?.photo)!)
        profileImageView.sd_setImageWithURL(url!)
        
        

        // Do any additional setup after loading the view.
    }

    var user: Users?
    var forumMsg: String?
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
