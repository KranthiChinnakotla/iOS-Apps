//
//  Users.swift
//  InClass05
//
//  Created by Kranthi Chinnakotla on 9/22/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

import Foundation
class Users{
    
    var firstName: String?
    var lastName: String?
    var email: String?
    var gender: String?
    
}
