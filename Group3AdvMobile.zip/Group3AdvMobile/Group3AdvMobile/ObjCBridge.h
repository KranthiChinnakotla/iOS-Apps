//
//  ObjCBridge.h
//  Group3AdvMobile
//
//  Created by Kranthi Chinnakotla on 9/18/16.
//  Copyright © 2016 edu.uncc.cs6010. All rights reserved.
//

#ifndef ObjCBridge_h
#define ObjCBridge_h
#import <EstimoteSDK/EstimoteSDK.h>

#endif /* ObjCBridge_h */
